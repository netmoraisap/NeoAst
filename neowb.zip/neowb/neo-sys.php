<?php
// variáves específicas da aplicação
$NEO_ARC="/home/gx/neowb/arc";
$NEO_WEB="/var/www/html/neo";
?>
