<?php 
// global
require_once '../gwb/ger-fun.php';

// verifica tempo do seletor
if ($ger_edt == "ini") { goto ger_ini; }
if ($ger_edt == "div") { goto ger_div; }
echo "ger_edt ?" ; exit ();

// inicializa
ger_ini:

// inicialila solicitando limpar ger_chv;; 
echo "ger_chv;;" ; exit ();

// retorna
exit ();

// diversos
ger_div:

// retorna
exit ();
?>
