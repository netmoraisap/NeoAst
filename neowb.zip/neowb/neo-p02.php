<?php 
// global
require_once '../gwb/ger-fun.php';

// verifica tempo de processo
if ($ger_edt == "enc") { goto ger_enc; }
echo "ger_edt ?" ; exit ();

// encerra
ger_enc:

// encerra solicitando uma chamada de página externa netmorais
echo "ger_ext;../ntm/ntm-s01.htm" ; exit ();

// retorna
exit ();
?>
