<?php 
// global
require_once '../gwb/ger-fun.php';

// verifica tempo de consulta
if ($ger_edt == "ini") { goto ger_ini; }
if ($ger_edt == "opc") { goto ger_opc; }
if ($ger_edt == "enc") { goto ger_enc; }
if ($ger_edt == "div") { goto ger_div; }
echo "ger_edt ?" ; exit ();

// inicializa
ger_ini:

// executa script do sistema, neowb-7di para atualizar
// ou não o json csv e banco de dados nos últimos 7 dias        
$ger_arq = "./neo-she"; $ger_ar1 = "neowb-7di"; 
$ger_ar2 = $ger_lan; ger_run_she ();

// retorna
exit ();

// opções
ger_opc:

// se ger_con não informado encerra ...
if ($ger_con == "") { exit (); }

// extrai de ger_con ger_fas, ger_seq e ger_arg
$palavras = explode (" ", $ger_con, 3); $ger_fas = $palavras [0];
$ger_seq = $palavras [1]; $ger_arg = $palavras [2];

// se ger_fas ou ger_seq não informado encerra ...
if ($ger_fas == "" || $ger_seq == "") { exit (); }

// se ger_fas inválido encerra ...
if ($ger_fas != "ini" && $ger_fas != "bac" && $ger_fas != "ahe") { exit (); }

// seta argumentos ger_ar3, ger_ar4 e ger_ar5 para neols-pid de acordo
// com a fase de consulta, para detalhe execute neols-pid
$ger_ar3 = $ger_ar4 = $ger_ar5 = "";
if ($ger_fas == "ini")
{ $ger_ar3 = "es"; $ger_ar4 = "1"; $ger_ar5 = $ger_arg; }
if ($ger_fas == "bac")
{ $ger_ar3 = "ls"; $ger_ar4 = $ger_seq; $ger_ar5 = $ger_arg; }
if ($ger_fas == "ahe")
{ $ger_ar3 = "gs"; $ger_ar4 = $ger_seq; $ger_ar5 = $ger_arg; }

// executa script do sistema, neols-pid para obter 
// quantidade nos dois sentidos, com ou sem argumento
echo "cen;"; // centraliza
$ger_arq = "./neo-she"; $ger_ar1 = "neols-pid"; 
$ger_ar2 = $ger_lan; ger_run_she ();

// se não houver ocorrências
if ($ger_ret != "0") {  exit (); }

// retorna
exit ();

// encerra
ger_enc:

// retorna
exit ();

// diversos
ger_div:

// retorna
exit ();
?>
