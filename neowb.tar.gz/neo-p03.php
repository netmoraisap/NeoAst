<?php 
// global
require_once '../gwb/ger-fun.php';

// verifica tempo de processo
if ($ger_edt == "enc") { goto ger_enc; }
echo "ger_edt ?" ; exit ();

// encerra
ger_enc:

// encerra solicitando ger-inf chamar html depois de exibir um arquivo texto
echo "ger_inf;s01:./neo-i04." . $ger_lan ; exit ();

// retorna
exit ();
?>
