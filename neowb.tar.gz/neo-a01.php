<?php 
// global
require_once '../gwb/ger-fun.php';

// verifica tempo de edição
if ($ger_edt == "ini") { goto ger_ini; }
if ($ger_edt == "vrf") { goto ger_vrf; }
if ($ger_edt == "enc") { goto ger_enc; }
if ($ger_edt == "div") { goto ger_div; }
echo "ger_edt ?" ; exit ();

// inicializa
ger_ini:

// se ger_con não informado encerra solicitando uma chamada de c01 ...
if ($ger_con == "") { echo "ger_htm;c01" ; exit (); }

// extrai a linha do asteróide de ger_con em ger_lin
$palavras = explode (" ", $ger_con, 5); $ger_lin = $palavras [0];

// se ger_lin não informado encerra solicitando uma chamada de c01 ...
if ($ger_lin == "") { echo "ger_htm;c01" ; exit (); }

// executa script do sistema, neols-lid para obter id, data, nome,
// velocidade do asteriod
$ger_arq = "./neo-she"; $ger_ar1 = "neols-lid"; $ger_ar2 = $ger_lan;
$ger_ar3 = $ger_lin; ger_run_she (); 

// retorna
exit ();

// verifica
ger_vrf:

// retorna
exit ();

// encerra
ger_enc:

// retorna
exit ();

// diversos
ger_div:

// retorna
exit ();
?>
